import React, { useState } from 'react';
import { SafeAreaView, StyleSheet, Image, View, Text, Linking, TouchableOpacity, Switch } from 'react-native';
import { Card, Button, Title, Paragraph } from 'react-native-paper';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import Icon from 'react-native-vector-icons/MaterialIcons';

// Import local profile image
import profilePic from 'WhatsApp Image 2025-02-17 at 09.15.15_8b074706.jpg';

// Home Screen Component
function HomeScreen({ navigation }) {
  const [followed, setFollowed] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);

  // Toggle Dark Mode
  const toggleDarkMode = () => setIsDarkMode(!isDarkMode);

  return (
    <View style={[styles.gradient, isDarkMode && styles.darkBackground]}>
      <SafeAreaView style={styles.container}>
        {/* Dark Mode Toggle */}
        <View style={styles.toggleContainer}>
          <Text style={[styles.toggleText, isDarkMode && styles.darkText]}>Dark Mode</Text>
          <Switch value={isDarkMode} onValueChange={toggleDarkMode} />
        </View>

        <Card style={[styles.card, isDarkMode && styles.darkCard]}>
          <Card.Content style={styles.content}>
            <Image source={profilePic} style={styles.profileImage} />
            <Title style={[styles.title, isDarkMode && styles.darkText]}>Abdul Rehman</Title>
            <Paragraph style={[styles.subtitle, isDarkMode && styles.darkText]}>Software Developer</Paragraph>
            <Paragraph style={[styles.bio, isDarkMode && styles.darkText]}>
              Passionate about building amazing apps and solving complex problems.
            </Paragraph>
          </Card.Content>

          <Card.Actions style={styles.actions}>
            <Button
              mode="contained"
              onPress={() => setFollowed(!followed)}
              style={[styles.button, followed ? styles.followedButton : styles.followButton]}
            >
              {followed ? 'Following' : 'Follow'}
            </Button>
            <Button
              mode="outlined"
              onPress={() => navigation.navigate('AboutMe', { isDarkMode })}
              style={styles.button}
              labelStyle={{ color: isDarkMode ? '#FFD700' : '#4c669f' }}
            >
              About Me
            </Button>
          </Card.Actions>

          <View style={styles.socialLinks}>
            <TouchableOpacity onPress={() => Linking.openURL('https://twitter.com')}>
              <Icon name="twitter" size={24} color="#1DA1F2" style={styles.icon} />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => Linking.openURL('https://linkedin.com')}>
              <Icon name="linkedin" size={24} color="#0077B5" style={styles.icon} />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => Linking.openURL('https://github.com')}>
              <Icon name="github" size={24} color="#333" style={styles.icon} />
            </TouchableOpacity>
          </View>
        </Card>
      </SafeAreaView>
    </View>
  );
}

// About Me Screen Component
function AboutMeScreen({ navigation, route }) {
  const { isDarkMode } = route.params || { isDarkMode: false };

  return (
    <View style={[styles.gradient, isDarkMode && styles.darkBackground]}>
      <SafeAreaView style={styles.aboutMeContainer}>
        <Card style={[styles.aboutMeCard, isDarkMode && styles.darkCard]}>
          <Card.Content>
            <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
              <Icon name="arrow-back" size={24} color={isDarkMode ? '#FFD700' : '#4c669f'} />
            </TouchableOpacity>
            <Title style={[styles.aboutMeTitle, isDarkMode && styles.darkText]}>About Me</Title>
            <Paragraph style={[styles.aboutMeText, isDarkMode && styles.darkText]}>
              <Text style={styles.bold}>Name:</Text> Abdul Rehman
            </Paragraph>
            <Paragraph style={[styles.aboutMeText, isDarkMode && styles.darkText]}>
              <Text style={styles.bold}>Address:</Text> 123 Main St, City, Country
            </Paragraph>
            <Paragraph style={[styles.aboutMeText, isDarkMode && styles.darkText]}>
              <Text style={styles.bold}>Interests:</Text> Computer Science, Mobile App Development, AI/ML
            </Paragraph>
            <Paragraph style={[styles.aboutMeText, isDarkMode && styles.darkText]}>
              <Text style={styles.bold}>Bio:</Text> I am a passionate software developer with a strong interest in building scalable and user-friendly applications. I love exploring new technologies and solving real-world problems.
            </Paragraph>
          </Card.Content>
        </Card>
      </SafeAreaView>
    </View>
  );
}

// Create Stack Navigator
const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} options={{ headerShown: false }} />
        <Stack.Screen name="AboutMe" component={AboutMeScreen} options={{ headerShown: false }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

// Styles
const styles = StyleSheet.create({
  gradient: {
    flex: 1,
    backgroundColor: '#4c669f',
  },
  darkBackground: {
    backgroundColor: '#121212',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  card: {
    width: '90%',
    borderRadius: 15,
    elevation: 10,
    backgroundColor: '#fff',
  },
  darkCard: {
    backgroundColor: '#1e1e1e',
  },
  content: {
    alignItems: 'center',
    padding: 20,
  },
  profileImage: {
    width: 120,
    height: 120,
    borderRadius: 60,
    marginBottom: 16,
    borderWidth: 3,
    borderColor: '#4c669f',
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 8,
    color: '#4c669f',
  },
  darkText: {
    color: '#FFD700',
  },
  subtitle: {
    fontSize: 18,
    color: '#666',
    marginBottom: 16,
  },
  bio: {
    fontSize: 14,
    textAlign: 'center',
    color: '#888',
    marginBottom: 16,
  },
  actions: {
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  button: {
    flex: 1,
    marginHorizontal: 5,
    borderRadius: 5,
  },
  followButton: {
    backgroundColor: '#4c669f',
  },
  followedButton: {
    backgroundColor: '#32CD32',
  },
  socialLinks: {
    flexDirection: 'row',
    justifyContent: 'center',
    paddingVertical: 10,
  },
  icon: {
    marginHorizontal: 10,
  },
  aboutMeContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  aboutMeCard: {
    width: '90%',
    borderRadius: 15,
    elevation: 10,
    backgroundColor: '#fff',
    padding: 20,
  },
  aboutMeTitle: {
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'center',
    color: '#4c669f',
  },
  aboutMeText: {
    fontSize: 16,
    marginBottom: 12,
    color: '#555',
  },
  bold: {
    fontWeight: 'bold',
  },
  backButton: {
    position: 'absolute',
    top: 10,
    left: 10,
    zIndex: 1,
  },
  toggleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  toggleText: {
    fontSize: 16,
    marginRight: 10,
    color: '#fff',
  },
});

