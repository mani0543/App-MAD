import React, { useState, useEffect } from 'react';
import { SafeAreaView, ScrollView, StyleSheet, TextInput, TouchableOpacity, View, ImageBackground, Animated } from 'react-native';
import { Card, Title, Paragraph } from 'react-native-paper';
import { MaterialIcons, Feather, Entypo } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

const WeatherApp = () => {
  const [location, setLocation] = useState('London');
  const [unit, setUnit] = useState('C');
  const [fadeAnim] = useState(new Animated.Value(0));

  const [weatherData] = useState({
    current: {
      temp: 22,
      condition: 'Sunny',
      humidity: 65,
      windSpeed: 12,
      uvIndex: 3,
      visibility: 10,
    },
    forecast: [
      { time: '09:00', temp: 20, icon: 'cloud' },
      { time: '12:00', temp: 25, icon: 'sun' },
      { time: '15:00', temp: 24, icon: 'cloud-rain' },
      { time: '18:00', temp: 21, icon: 'moon' },
    ],
  });

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 1000,
      useNativeDriver: true,
    }).start();
  }, []);

  const getBackgroundImage = () => {
    switch (weatherData.current.condition) {
      case 'Sunny':
        return require('./Capture.PNG');
      case 'Rainy':
        return require('./sunny.PNG');
      default:
        return require('./cloudy.PNG');
    }
  };

  return (
    <ImageBackground source={getBackgroundImage()} style={styles.backgroundImage}>
      <LinearGradient colors={['rgba(0,0,0,0.3)', 'rgba(0,0,0,0.9)']} style={styles.overlay}>
        <SafeAreaView style={styles.safeArea}>
          <ScrollView>
            {/* Header Section */}
            <View style={styles.header}>
              <TextInput
                style={styles.searchInput}
                placeholder="Search location..."
                placeholderTextColor="#ccc"
                value={location}
                onChangeText={setLocation}
              />
              <TouchableOpacity onPress={() => setUnit(unit === 'C' ? 'F' : 'C')} style={styles.unitSwitch}>
                <MaterialIcons name="thermostat" size={24} color="white" />
                <Title style={styles.unitText}>°{unit}</Title>
              </TouchableOpacity>
            </View>

            {/* Current Weather Section */}
            <Animated.View style={[styles.currentWeather, { opacity: fadeAnim }]}>
              <Title style={styles.locationText}>{location}</Title>
              <Title style={styles.temperatureText}>{weatherData.current.temp}°{unit}</Title>
              <Paragraph style={styles.conditionText}>{weatherData.current.condition}</Paragraph>
            </Animated.View>

            {/* Weather Highlights */}
            <View style={styles.highlightsContainer}>
              {[
                { icon: 'wind', value: `${weatherData.current.windSpeed} km/h`, label: 'Wind Speed' },
                { icon: 'drop', value: `${weatherData.current.humidity}%`, label: 'Humidity' },
                { icon: 'visibility', value: `${weatherData.current.visibility} km`, label: 'Visibility' },
                { icon: 'sun', value: weatherData.current.uvIndex, label: 'UV Index' },
              ].map((item, index) => (
                <Card key={index} style={styles.highlightCard}>
                  <Feather name={item.icon} size={24} color="white" />
                  <Paragraph style={styles.highlightText}>{item.value}</Paragraph>
                  <Paragraph style={styles.highlightLabel}>{item.label}</Paragraph>
                </Card>
              ))}
            </View>

            {/* Hourly Forecast */}
            <View style={styles.forecastContainer}>
              <Title style={styles.sectionTitle}>Hourly Forecast</Title>
              <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                {weatherData.forecast.map((item, index) => (
                  <Card key={index} style={styles.forecastCard}>
                    <Paragraph style={styles.forecastTime}>{item.time}</Paragraph>
                    <Feather name={item.icon} size={32} color="white" />
                    <Paragraph style={styles.forecastTemp}>{item.temp}°{unit}</Paragraph>
                  </Card>
                ))}
              </ScrollView>
            </View>

            {/* Weekly Forecast */}
            <View style={styles.weeklyForecast}>
              <Title style={styles.sectionTitle}>7-Day Forecast</Title>
              {[1, 2, 3, 4, 5, 6, 7].map((day) => (
                <View key={day} style={styles.weeklyItem}>
                  <Paragraph style={styles.weeklyDay}>Day {day}</Paragraph>
                  <Feather name="sun" size={24} color="white" />
                  <Paragraph style={styles.weeklyTemp}>22° / 18°</Paragraph>
                </View>
              ))}
            </View>
          </ScrollView>
        </SafeAreaView>
      </LinearGradient>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    resizeMode: 'cover',
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.4)',
  },
  safeArea: {
    flex: 1,
    marginTop: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 30,
  },
  searchInput: {
    flex: 1,
    color: 'white',
    fontSize: 18,
    marginRight: 15,
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.5)',
  },
  unitSwitch: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  unitText: {
    color: 'white',
    fontSize: 16,
    marginLeft: 5,
  },
  currentWeather: {
    alignItems: 'center',
    marginBottom: 30,
  },
  locationText: {
    color: 'white',
    fontSize: 28,
    fontWeight: '300',
  },
  temperatureText: {
    color: 'white',
    fontSize: 72,
    fontWeight: '200',
    marginVertical: 8,
  },
  conditionText: {
    color: 'white',
    fontSize: 20,
    fontWeight: '300',
  },
  highlightsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    paddingHorizontal: 15,
    marginBottom: 25,
  },
  highlightCard: {
    width: '48%',
    alignItems: 'center',
    padding: 15,
    marginVertical: 8,
    backgroundColor: 'rgba(255,255,255,0.15)',
  },
  highlightText: {
    color: 'white',
    fontSize: 24,
    marginVertical: 8,
  },
  highlightLabel: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 14,
  },
  forecastContainer: {
    marginBottom: 25,
    paddingHorizontal: 15,
  },
  sectionTitle: {
    color: 'white',
    fontSize: 20,
    marginBottom: 15,
    paddingLeft: 10,
  },
  forecastCard: {
    alignItems: 'center',
    padding: 15,
    marginRight: 10,
    backgroundColor: 'rgba(255,255,255,0.15)',
  },
  forecastTime: {
    color: 'white',
    fontSize: 16,
  },
  forecastTemp: {
    color: 'white',
    fontSize: 18,
    marginTop: 8,
  },
  weeklyForecast: {
    paddingHorizontal: 15,
  },
  weeklyItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.2)',
  },
  weeklyDay: {
    color: 'white',
    fontSize: 16,
  },
  weeklyTemp: {
    color: 'white',
    fontSize: 16,
  },
});

export default WeatherApp;
