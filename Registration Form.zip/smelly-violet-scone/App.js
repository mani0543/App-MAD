import React, { useState } from 'react';
import {
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Alert,
  ScrollView
} from 'react-native';
import { Button, RadioButton, HelperText } from 'react-native-paper';
import DropDownPicker from 'react-native-dropdown-picker';
import DateTimePicker from '@react-native-community/datetimepicker';

export default function RegistrationForm() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [dob, setDob] = useState(new Date());
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [gender, setGender] = useState('male');
  const [course, setCourse] = useState(null);
  const [openDropdown, setOpenDropdown] = useState(false);
  const [courses, setCourses] = useState([
    { label: 'Computer Science', value: 'cs' },
    { label: 'Business Administration', value: 'ba' },
    { label: 'Mechanical Engineering', value: 'me' },
    { label: 'Psychology', value: 'psy' },
  ]);

  // Form Validation
  const isEmailValid = email.includes('@');
  const isPhoneValid = phone.length === 10;
  const isNameValid = name.length > 2;

  const handleSubmit = () => {
    if (!isNameValid || !isEmailValid || !isPhoneValid || !course) {
      Alert.alert('Error', 'Please fill all fields correctly.');
      return;
    }

    Alert.alert('Success', `Welcome, ${name}! Your registration is complete.`);
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.form}>
        <Text style={styles.title}>University Registration</Text>

        {/* Name Input */}
        <TextInput
          style={styles.input}
          placeholder="Full Name"
          placeholderTextColor="#aaa"
          value={name}
          onChangeText={setName}
        />
        {!isNameValid && <HelperText type="error">Name must be at least 3 characters.</HelperText>}

        {/* Email Input */}
        <TextInput
          style={styles.input}
          placeholder="Email"
          placeholderTextColor="#aaa"
          keyboardType="email-address"
          value={email}
          onChangeText={setEmail}
        />
        {!isEmailValid && <HelperText type="error">Enter a valid email.</HelperText>}

        {/* Phone Input */}
        <TextInput
          style={styles.input}
          placeholder="Phone Number"
          placeholderTextColor="#aaa"
          keyboardType="numeric"
          value={phone}
          onChangeText={setPhone}
        />
        {!isPhoneValid && <HelperText type="error">Phone must be 10 digits.</HelperText>}

        {/* Date of Birth Picker */}
        <TouchableOpacity style={styles.datePicker} onPress={() => setShowDatePicker(true)}>
          <Text style={styles.dateText}>Date of Birth: {dob.toDateString()}</Text>
        </TouchableOpacity>
        {showDatePicker && (
          <DateTimePicker
            value={dob}
            mode="date"
            display="default"
            onChange={(event, selectedDate) => {
              setShowDatePicker(false);
              if (selectedDate) setDob(selectedDate);
            }}
          />
        )}

        {/* Gender Selection */}
        <Text style={styles.label}>Gender:</Text>
        <View style={styles.radioGroup}>
          <RadioButton.Group onValueChange={setGender} value={gender}>
            <View style={styles.radioItem}>
              <RadioButton value="male" />
              <Text style={styles.radioText}>Male</Text>
            </View>
            <View style={styles.radioItem}>
              <RadioButton value="female" />
              <Text style={styles.radioText}>Female</Text>
            </View>
          </RadioButton.Group>
        </View>

        {/* Course Selection Dropdown */}
        <Text style={styles.label}>Select Course:</Text>
        <DropDownPicker
          open={openDropdown}
          value={course}
          items={courses}
          setOpen={setOpenDropdown}
          setValue={setCourse}
          setItems={setCourses}
          placeholder="Select a course"
          style={styles.dropdown}
          dropDownContainerStyle={styles.dropdownContainer}
        />

        {/* Submit Button */}
        <Button mode="contained" onPress={handleSubmit} style={styles.submitButton}>
          Register
        </Button>
      </ScrollView>
    </SafeAreaView>
  );
}

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f0f5',
  },
  form: {
    padding: 20,
    alignItems: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#4c669f',
  },
  input: {
    width: '100%',
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#4c669f',
    marginBottom: 10,
    fontSize: 16,
    color: '#333',
  },
  datePicker: {
    width: '100%',
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#4c669f',
    marginBottom: 10,
    alignItems: 'center',
  },
  dateText: {
    fontSize: 16,
    color: '#4c669f',
  },
  label: {
    fontSize: 18,
    fontWeight: 'bold',
    alignSelf: 'flex-start',
    marginTop: 10,
    color: '#333',
  },
  radioGroup: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    marginBottom: 10,
  },
  radioItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 20,
  },
  radioText: {
    fontSize: 16,
    color: '#333',
  },
  dropdown: {
    width: '100%',
    borderColor: '#4c669f',
  },
  dropdownContainer: {
    width: '100%',
    borderColor: '#4c669f',
  },
  submitButton: {
    marginTop: 20,
    backgroundColor: '#4c669f',
    paddingVertical: 10,
    width: '100%',
    borderRadius: 8,
  },
});

