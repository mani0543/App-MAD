import {
  View,
  Text,
  SafeAreaView,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  ScrollView,
  Platform,
} from 'react-native';
import React, { useState, useEffect, useRef } from 'react';

export default function App() {
  const [message, setMessage] = useState('');
  const [conversation, setConversation] = useState([]);
  const [darkMode, setDarkMode] = useState(false);
  const scrollViewRef = useRef();

  const handleSendMessage = async () => {
    if (!message.trim()) return; // Don't send empty messages

    // Add the user's message to the conversation
    const userMessage = { role: 'user', content: message };
    const updatedConversation = [...conversation, userMessage];
    setConversation(updatedConversation);
    setMessage('');

    // Get the AI's response
    await getResponse(updatedConversation);
  };

  const getResponse = async (conversation) => {
    const userMessage =
      conversation[conversation.length - 1].content.toLowerCase();

    // Check if the user is asking about the bot's name
    if (
      userMessage.includes('name') &&
      (userMessage.includes('your') || userMessage.includes('bot'))
    ) {
      const aiMessage = {
        role: 'model',
        content: 'My name is ManisAI.',
      };
      setConversation((prev) => [...prev, aiMessage]);
      return; // Exit the function after sending the response
    }

    // Check if the user is asking about the developer
    if (
      userMessage.includes('developer') ||
      userMessage.includes('abdul rehman')
    ) {
      const aiMessage = {
        role: 'model',
        content:
          'Abdul Rehman developed me. ',
      };
      setConversation((prev) => [...prev, aiMessage]);
      return; // Exit the function after sending the response
    }

 if (
      userMessage.includes('Where') ||
      userMessage.includes('abdul rehman') || userMessage.includes('study')
    ) {
      const aiMessage = {
        role: 'model',
        content:
          'Abdul rehman studys At Abasyn University ',
      };
      setConversation((prev) => [...prev, aiMessage]);
      return; // Exit the function after sending the response
    }

    // If no specific keywords are detected, proceed with the Gemini API call
    const API_KEY = 'AIzaSyDd2tyi1VQZlQ09Gghn1ALOtWNUpvPxpaE'; // Your Google Generative AI API key
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${API_KEY}`;

    try {
      // Prepare the request payload for Gemini API
      const payload = {
        contents: conversation.map((msg) => ({
          role: msg.role === 'user' ? 'user' : 'model',
          parts: [{ text: msg.content }],
        })),
      };

      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      const data = await response.json();

      if (data.candidates && data.candidates.length > 0) {
        const aiMessage = {
          role: 'model',
          content: data.candidates[0].content.parts[0].text,
        };
        setConversation((prev) => [...prev, aiMessage]); // Add AI's response to the conversation
      }
    } catch (error) {
      console.error('Error fetching response:', error);
    }
  };

  // Scroll to the bottom of the conversation when new messages are added
  useEffect(() => {
    if (scrollViewRef.current) {
      scrollViewRef.current.scrollToEnd({ animated: true });
    }
  }, [conversation]);

  // Toggle dark mode
  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  // Clear all chats
  const clearChats = () => {
    setConversation([]);
  };

  return (
    <SafeAreaView style={[styles.container, darkMode && styles.darkContainer]}>
      <View style={styles.header}>
        <View style={[styles.nameCard, darkMode && styles.darkNameCard]}>
          <Text style={[styles.nameText, darkMode && styles.darkNameText]}>
            ManisAI
          </Text>
        </View>
        <View style={styles.headerButtons}>
          <TouchableOpacity onPress={toggleDarkMode} style={styles.iconButton}>
            <Text style={styles.iconButtonText}>
              {darkMode ? '🌞' : '🌙'}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={clearChats} style={styles.iconButton}>
            <Text style={styles.iconButtonText}>🗑️</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Conversation History */}
      <ScrollView
        ref={scrollViewRef}
        style={styles.conversation}
        contentContainerStyle={styles.conversationContent}>
        {conversation.map((item, index) => (
          <View
            key={index}
            style={[
              styles.messageBubble,
              item.role === 'user'
                ? [styles.userBubble, darkMode && styles.darkUserBubble]
                : [styles.aiBubble, darkMode && styles.darkAiBubble],
            ]}>
            <Text
              style={[
                styles.messageText,
                darkMode && styles.darkMessageText,
                item.role === 'user' && styles.userMessageText,
              ]}>
              {item.content}
            </Text>
          </View>
        ))}
      </ScrollView>

      {/* Input Area */}
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={[styles.inputContainer, darkMode && styles.darkInputContainer]}>
        <TextInput
          style={[styles.input, darkMode && styles.darkInput]}
          value={message}
          onChangeText={(text) => setMessage(text)}
          placeholder="Type a message..."
          placeholderTextColor={darkMode ? '#999' : '#ccc'}
        />
        <TouchableOpacity
          style={[styles.sendButton, darkMode && styles.darkSendButton]}
          onPress={handleSendMessage}>
          <Text style={styles.sendButtonText}>Send</Text>
        </TouchableOpacity>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  darkContainer: {
    backgroundColor: '#121212',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: '#007AFF',
  },
  nameCard: {
    backgroundColor: '#fff',
    borderRadius: 20,
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  darkNameCard: {
    backgroundColor: '#333',
  },
  nameText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#007AFF',
  },
  darkNameText: {
    color: '#fff',
  },
  headerButtons: {
    flexDirection: 'row',
  },
  iconButton: {
    marginLeft: 16,
  },
  iconButtonText: {
    fontSize: 24,
  },
  conversation: {
    flex: 1,
    paddingHorizontal: 16,
  },
  conversationContent: {
    paddingBottom: 16,
  },
  messageBubble: {
    maxWidth: '80%',
    padding: 12,
    borderRadius: 12,
    marginVertical: 8,
  },
  userBubble: {
    alignSelf: 'flex-end',
    backgroundColor: '#007AFF',
  },
  darkUserBubble: {
    backgroundColor: '#1E90FF',
  },
  aiBubble: {
    alignSelf: 'flex-start',
    backgroundColor: '#E5E5EA',
  },
  darkAiBubble: {
    backgroundColor: '#333',
  },
  messageText: {
    fontSize: 16,
    color: '#000',
  },
  darkMessageText: {
    color: '#fff',
  },
  userMessageText: {
    color: '#fff',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#ccc',
  },
  darkInputContainer: {
    backgroundColor: '#1E1E1E',
    borderTopColor: '#444',
  },
  input: {
    flex: 1,
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 20,
    paddingHorizontal: 16,
    marginRight: 8,
    backgroundColor: '#fff',
  },
  darkInput: {
    backgroundColor: '#333',
    borderColor: '#444',
    color: '#fff',
  },
  sendButton: {
    backgroundColor: '#007AFF',
    borderRadius: 20,
    paddingVertical: 10,
    paddingHorizontal: 20,
  },
  darkSendButton: {
    backgroundColor: '#1E90FF',
  },
  sendButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});